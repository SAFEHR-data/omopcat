# calypso 0.1.0

The minimal data catalogue.

* Implemented prototype (#3)
* Added preprocessing script to calculate summary statistics (#22)
* Made dashboard reactive to concept selection and date range filtering (#31, #37)
* Added handling of categorical concepts (#32)
* Added setup and use of realistic test data (#24)
* Set up deployment environment (#44, #45)
* Added masking of low-frequency statistics (#51)
