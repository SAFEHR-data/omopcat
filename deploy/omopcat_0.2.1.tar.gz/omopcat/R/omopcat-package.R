#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom rlang .data
#' @import shiny
#' @import bslib
#' @import ggplot2
## usethis namespace: end
NULL
